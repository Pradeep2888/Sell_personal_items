function PlanAndFeatures() {
  return (
    <div>PlanAndFeatures</div>
  )
}

export default PlanAndFeatures